# File-Handling-and-Array-Operations

Ejecutar el archivo file_handling_and_array_perations.py y se obtiene los resultados solicitados