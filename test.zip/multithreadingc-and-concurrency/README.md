# multithreadingc-and-concurrency
Se debe ejecutar los archivos use_json.py y use_multithreading.py